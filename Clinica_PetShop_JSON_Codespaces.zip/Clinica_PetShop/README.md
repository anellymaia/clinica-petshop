# Clínica Pet Shop — Cadastro de Pacientes

CRUD para cadastrar, visualizar, editar, pesquisar e excluir pacientes de uma clínica veterinária.

## Tecnologias
React + Vite (frontend), Node.js + Express (backend) e arquivo JSON para persistência dos dados. Não precisa configurar MySQL nem Prisma.

## Executar no GitHub Codespaces
Abra dois terminais. No primeiro:

```bash
cd backend
npm install
npm run dev
```

No segundo terminal, na raiz do projeto:

```bash
cd frontend
npm install
npm run dev
```

Abra a porta 5173 quando o Codespaces oferecer o link. A API usa a porta 3001. Os cadastros ficam salvos em `backend/data/pacientes.json`.
