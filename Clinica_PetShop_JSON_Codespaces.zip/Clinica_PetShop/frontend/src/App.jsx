import { useEffect, useMemo, useState } from 'react';
import api from './services/api';
import './App.css';

const vazio = { nomePet: '', especieRaca: '', idade: '', nomeTutor: '', telefoneTutor: '' };

export default function App() {
  const [pacientes, setPacientes] = useState([]);
  const [form, setForm] = useState(vazio);
  const [editando, setEditando] = useState(null);
  const [busca, setBusca] = useState('');
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');
  const [salvando, setSalvando] = useState(false);

  async function carregar() {
    try {
      const resposta = await api.get('/pacientes');
      setPacientes(resposta.data);
      setErro('');
    } catch {
      setErro('Não foi possível carregar os pacientes. Confira se o servidor da API está funcionando.');
    }
  }
  useEffect(() => { carregar(); }, []);

  const filtrados = useMemo(() => pacientes.filter(p =>
    `${p.nomePet} ${p.especieRaca} ${p.nomeTutor}`.toLowerCase().includes(busca.toLowerCase())
  ), [pacientes, busca]);

  function editar(p) {
    setEditando(p.id);
    setForm({ nomePet: p.nomePet, especieRaca: p.especieRaca, idade: String(p.idade), nomeTutor: p.nomeTutor, telefoneTutor: p.telefoneTutor || '' });
    setErro(''); setSucesso('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function cancelar() { setEditando(null); setForm(vazio); }
  async function salvar(evento) {
    evento.preventDefault(); setSalvando(true); setErro(''); setSucesso('');
    const dados = { ...form, idade: Number(form.idade) };
    try {
      if (editando !== null) await api.put(`/pacientes/${editando}`, dados);
      else await api.post('/pacientes', dados);
      setSucesso(editando !== null ? 'Cadastro atualizado com sucesso!' : 'Paciente cadastrado com sucesso!');
      cancelar(); await carregar();
    } catch (e) { setErro(e.response?.data?.erro || 'Não foi possível salvar o cadastro.'); }
    finally { setSalvando(false); }
  }
  async function excluir(p) {
    if (!window.confirm(`Deseja realmente excluir o cadastro de ${p.nomePet}?`)) return;
    try {
      await api.delete(`/pacientes/${p.id}`);
      if (editando === p.id) cancelar();
      setSucesso(`Cadastro de ${p.nomePet} excluído.`); setErro(''); await carregar();
    } catch (e) { setErro(e.response?.data?.erro || 'Não foi possível excluir o paciente.'); }
  }

  return <main className="container">
    <header className="topo">
      <div className="marca">🐾</div>
      <div><p className="sobretitulo">SISTEMA DE ATENDIMENTO</p><h1>Clínica Pet Shop</h1><p className="subtitulo">Cadastro e acompanhamento dos pacientes</p></div>
    </header>

    <section className="painel">
      <div className="titulo-painel"><div><span className="etiqueta">{editando !== null ? 'ATUALIZAÇÃO' : 'NOVO REGISTRO'}</span><h2>{editando !== null ? 'Editar paciente' : 'Cadastrar paciente'}</h2></div><span className="icone-painel">＋</span></div>
      <form onSubmit={salvar}>
        <div className="grade">
          <label>Nome do pet *<input required maxLength="150" value={form.nomePet} onChange={e => setForm({ ...form, nomePet: e.target.value })} placeholder="Ex.: Mel" /></label>
          <label>Espécie / raça *<input required maxLength="120" value={form.especieRaca} onChange={e => setForm({ ...form, especieRaca: e.target.value })} placeholder="Ex.: Cão / Golden Retriever" /></label>
          <label>Idade (anos) *<input required type="number" min="0" step="1" value={form.idade} onChange={e => setForm({ ...form, idade: e.target.value })} placeholder="Ex.: 3" /></label>
          <label>Nome do dono (tutor) *<input required maxLength="150" value={form.nomeTutor} onChange={e => setForm({ ...form, nomeTutor: e.target.value })} placeholder="Nome completo do tutor" /></label>
          <label className="campo-largo">Telefone do tutor<input type="tel" maxLength="30" value={form.telefoneTutor} onChange={e => setForm({ ...form, telefoneTutor: e.target.value })} placeholder="(00) 00000-0000 (opcional)" /></label>
        </div>
        <div className="acoes"><button className="principal" disabled={salvando} type="submit">{salvando ? 'Salvando...' : editando !== null ? 'Salvar alterações' : 'Cadastrar paciente'}</button>{editando !== null && <button className="secundario" type="button" onClick={cancelar}>Cancelar</button>}</div>
      </form>
    </section>

    {erro && <p className="mensagem erro" role="alert">{erro}</p>}
    {sucesso && <p className="mensagem sucesso" role="status">{sucesso}</p>}

    <section className="painel lista">
      <div className="cabecalho-lista"><div><span className="etiqueta">PRONTUÁRIOS</span><h2>Pacientes cadastrados <span className="contador">{pacientes.length}</span></h2></div><div className="busca"><span>⌕</span><input aria-label="Buscar paciente" placeholder="Buscar pet ou tutor..." value={busca} onChange={e => setBusca(e.target.value)} /></div></div>
      {filtrados.length === 0 ? <div className="vazio"><span>🐶</span><p>{pacientes.length === 0 ? 'Nenhum paciente cadastrado ainda.' : 'Nenhum paciente encontrado para essa busca.'}</p></div> :
        <div className="tabela-scroll"><table><thead><tr><th>Paciente</th><th>Espécie / raça</th><th>Idade</th><th>Tutor</th><th>Telefone</th><th>Ações</th></tr></thead><tbody>
          {filtrados.map(p => <tr key={p.id}><td><strong>{p.nomePet}</strong><small>Cadastro #{p.id}</small></td><td>{p.especieRaca}</td><td>{p.idade} {p.idade === 1 ? 'ano' : 'anos'}</td><td>{p.nomeTutor}</td><td>{p.telefoneTutor || '—'}</td><td><div className="acoes-tabela"><button className="editar" onClick={() => editar(p)}>Editar</button><button className="excluir" onClick={() => excluir(p)}>Excluir</button></div></td></tr>)}
        </tbody></table></div>}
      <p className="rodape-lista">Exibindo {filtrados.length} de {pacientes.length} paciente(s).</p>
    </section>
    <footer>Clínica Pet Shop · Sistema de cadastro de pacientes</footer>
  </main>;
}
