import express from 'express';
import cors from 'cors';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
app.use(cors());
app.use(express.json());
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const arquivo = path.join(__dirname, '../data/pacientes.json');

async function lerPacientes() {
  try { return JSON.parse(await fs.readFile(arquivo, 'utf8')); }
  catch (erro) {
    if (erro.code === 'ENOENT') { await fs.mkdir(path.dirname(arquivo), { recursive: true }); await fs.writeFile(arquivo, '[]'); return []; }
    throw erro;
  }
}
async function salvarPacientes(pacientes) {
  await fs.mkdir(path.dirname(arquivo), { recursive: true });
  await fs.writeFile(arquivo, JSON.stringify(pacientes, null, 2), 'utf8');
}
function validar(d) {
  if (!String(d.nomePet ?? '').trim() || !String(d.especieRaca ?? '').trim() ||
      !String(d.nomeTutor ?? '').trim() || d.idade === '' || d.idade === undefined ||
      !Number.isInteger(Number(d.idade)) || Number(d.idade) < 0) {
    return 'Informe nome do pet, espécie/raça, idade (número inteiro igual ou maior que zero) e nome do tutor.';
  }
  return null;
}
app.get('/api/pacientes', async (_req, res) => {
  try { res.json((await lerPacientes()).sort((a,b) => a.nomePet.localeCompare(b.nomePet))); }
  catch (e) { console.error(e); res.status(500).json({ erro: 'Não foi possível carregar os pacientes.' }); }
});
app.post('/api/pacientes', async (req, res) => {
  const erro = validar(req.body); if (erro) return res.status(400).json({ erro });
  try {
    const pacientes = await lerPacientes();
    const paciente = { id: pacientes.length ? Math.max(...pacientes.map(p => p.id)) + 1 : 1,
      nomePet: req.body.nomePet.trim(), especieRaca: req.body.especieRaca.trim(), idade: Number(req.body.idade),
      nomeTutor: req.body.nomeTutor.trim(), telefoneTutor: req.body.telefoneTutor?.trim() || '' };
    pacientes.push(paciente); await salvarPacientes(pacientes); res.status(201).json(paciente);
  } catch (e) { console.error(e); res.status(500).json({ erro: 'Não foi possível cadastrar o paciente.' }); }
});
app.put('/api/pacientes/:id', async (req, res) => {
  const erro = validar(req.body); if (erro) return res.status(400).json({ erro });
  try {
    const pacientes = await lerPacientes(); const id = Number(req.params.id); const i = pacientes.findIndex(p => p.id === id);
    if (i < 0) return res.status(404).json({ erro: 'Paciente não encontrado.' });
    pacientes[i] = { ...pacientes[i], nomePet: req.body.nomePet.trim(), especieRaca: req.body.especieRaca.trim(),
      idade: Number(req.body.idade), nomeTutor: req.body.nomeTutor.trim(), telefoneTutor: req.body.telefoneTutor?.trim() || '' };
    await salvarPacientes(pacientes); res.json(pacientes[i]);
  } catch (e) { console.error(e); res.status(500).json({ erro: 'Não foi possível atualizar o paciente.' }); }
});
app.delete('/api/pacientes/:id', async (req, res) => {
  try {
    const pacientes = await lerPacientes(); const id = Number(req.params.id); const restantes = pacientes.filter(p => p.id !== id);
    if (restantes.length === pacientes.length) return res.status(404).json({ erro: 'Paciente não encontrado.' });
    await salvarPacientes(restantes); res.status(204).end();
  } catch (e) { console.error(e); res.status(500).json({ erro: 'Não foi possível excluir o paciente.' }); }
});
app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));
const port = process.env.PORT || 3001;
app.listen(port, '0.0.0.0', () => console.log(`API da Clínica Pet Shop rodando na porta ${port}`));
